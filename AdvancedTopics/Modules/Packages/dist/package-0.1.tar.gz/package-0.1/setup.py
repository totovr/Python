from setuptools import setup

setup(
    name="package",
    version="0.1",
    description="This is a package example",
    author="Tono Vega",
    author_email="a.vegaramirez76@gmail.com",
    url="https://totovr.github.io/",
    scripts=[],
    packages=["package", "package.bye", "package.hello"]
)
