# This is a module with greeting functions
def greeting():
  print("Hello, I'm greeting you from the greeting function of the submodule greetings")

class Greeting():
    def __init__(self):
        print("Hello, I'm greeting you from the Greetings class of the submodule greetings")
