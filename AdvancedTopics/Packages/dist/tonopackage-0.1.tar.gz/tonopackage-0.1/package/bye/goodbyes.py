# This is a module with goodbyes functions
def bye():
  print("Bye, I'm goodbyes you from the goodbye function of the submodule goodbyes")

class Goodbye():
    def __init__(self):
        print("HBye, I'm goodbyes you from the goodbye Class of the submodule goodbyes")
